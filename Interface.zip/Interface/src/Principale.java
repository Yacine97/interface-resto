import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

public class Principale extends JFrame {
public Principale() {
	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	this.setVisible(true);
	this.setAlwaysOnTop(true);
	this.setLocationRelativeTo(null);
	this.setSize(1200, 1200);
	this.setResizable(true);
	JPanel cp=(JPanel) this.getContentPane();
	cp.setLayout(new GridLayout(2,2));
	Image fritimage = null;
	try {
		fritimage = ImageIO.read(getClass().getResource("imgs/frite.jpg"));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	JButton frite=new JButton ("FRITE");
	frite.setIcon(new ImageIcon(fritimage));
	frite.setFont(new Font("Arial",Font.PLAIN,30));
	cp.add(frite);
	JButton pizza=new JButton ("PIZZA");
	pizza.setPreferredSize(new Dimension(200,100));
	BufferedImage imgpizza=null;
	try {
		imgpizza=ImageIO.read(getClass().getResource("imgs/pizza.jpg"));
	} catch  (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	Image dpizza=imgpizza.getScaledInstance(pizza.getWidth(), pizza.getHeight(), Image.SCALE_SMOOTH);
	
	pizza.setIcon(new ImageIcon(dpizza));
	pizza.setFont(new Font("Arial",Font.PLAIN,30));
	cp.add(pizza);
	Image imgtacos=null;
	try {
		imgtacos=ImageIO.read(getClass().getResource("imgs/tacos.jpeg"));
	} catch  (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	JButton tacos=new JButton ("TACOS");
	tacos.setIcon(new ImageIcon(imgtacos));
	tacos.setFont(new Font("Arial",Font.PLAIN,30));
	cp.add(tacos);
	Image imgpoulet=null;
	try {
		imgpoulet=ImageIO.read(getClass().getResource("imgs/poulet.jpg"));
	} catch  (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	JButton poulet=new JButton ("POULET");
	poulet.setIcon(new ImageIcon(imgpoulet));
	poulet.setFont(new Font("Arial",Font.PLAIN,30));
	cp.add(poulet);
	
	
	
}

	public static void main(String[] args) throws Exception {
		UIManager.setLookAndFeel(new NimbusLookAndFeel());
		Principale window=new Principale();
		window.setTitle("Menu principal");
		

	}

}
